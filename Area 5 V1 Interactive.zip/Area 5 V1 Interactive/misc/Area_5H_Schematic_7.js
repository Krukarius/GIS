var json_Area_5H_Schematic_7 = {
"type": "FeatureCollection",
"name": "Area_5H_Schematic_7",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name": "Schematic", "Path": "<a href='images/Area5Schematic.PNG'><img src = 'images/images/Area5Schematic.PNG' width='250' height='200'></a>" }, "geometry": { "type": "Point", "coordinates": [ -0.201373095558392, 52.082712362234155 ] } }
]
}
