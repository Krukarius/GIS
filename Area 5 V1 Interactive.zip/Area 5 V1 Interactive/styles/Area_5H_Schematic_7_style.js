var size = 0;
var placement = 'point';

var style_Area_5H_Schematic_7 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = ""
    var labelText = "";
    size = 0;
    var labelFont = "25px \'MS Shell Dlg 2\', sans-serif";
    var labelFill = "#000000";
    var bufferColor = "";
    var bufferWidth = 0;
    var textAlign = "top";
    var offsetX = "1";
    var offsetY = "2";
    var placement = 'point';
    if (feature.get("Name") !== null) {
        labelText = String(feature.get("Name"));
    }
    var style = [ new ol.style.Style({
        image: new ol.style.RegularShape({radius: 15.6 + size, points: 8,
            radius2: 7.8, stroke: new ol.style.Stroke({color: 'rgba(9,4,2,1.0)', lineDash: null, lineCap: 'butt', lineJoin: 'miter', width: 1}), fill: new ol.style.Fill({color: 'rgba(9,4,2,1.0)'})}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, offsetX, offsetY, bufferColor,
                              bufferWidth)
    })];

    return style;
};
