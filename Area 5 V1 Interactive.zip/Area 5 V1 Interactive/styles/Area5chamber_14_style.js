var size = 0;
var placement = 'point';



function categories_Area5chamber_14(feature, value, size, resolution, labelText,
                       labelFont, labelFill, bufferColor, bufferWidth,
                       placement) {
                switch(value.toString()) {case 'BT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(35,35,35,1.0)', lineDash: null, lineCap: 'butt', lineJoin: 'miter', width: 0}),fill: new ol.style.Fill({color: 'rgba(0,0,0,1.0)'}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'Voneus':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(35,35,35,1.0)', lineDash: null, lineCap: 'butt', lineJoin: 'miter', width: 0}),fill: new ol.style.Fill({color: 'rgba(252,0,0,1.0)'}),
        text: createTextStyle(feature, resolution)
    })];
                    break;}};
					

var style_Area5chamber_14 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = feature.get("Chamber Type");
    var labelText = "";
    size = 0;
    var labelFont = "15px \'MS Shell Dlg 2\', sans-serif";
    var labelFill = "#787878";
    var bufferColor = "";
    var bufferWidth = 0;
    var textAlign = "center";
    var offsetX = 0;
    var offsetY = 0;
    var placement = 'point';
      if (feature.get("Chamber No") !== null) {
        labelText = String(feature.get("Chamber No")); labelFont = "15px \'MS Shell Dlg 2\', sans-serif";
    }
	else if (feature.get("X") !== null) {
        labelText = String(feature.get("X")); labelFont = "15px \'MS Shell Dlg 2\', sans-serif";
    }

    
	var style = categories_Area5chamber_14(feature, value, size, resolution, labelText,
                          labelFont, labelFill, bufferColor,
                          bufferWidth, placement);
					
    return style;
	
};


