var json_Area_5J_Blockage_5 = {
"type": "FeatureCollection",
"name": "Area_5J_Blockage_5",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Blockage": "1", "Description": "Blockage located at the base of the pole", "Path": "Supporting_Docs\\A55.jpg" }, "geometry": { "type": "Point", "coordinates": [ -0.202142244376326, 52.081804716843564 ] } }
]
}
