var json_Area_5E_NewOHroutefromEL_10 = {
"type": "FeatureCollection",
"name": "Area_5E_NewOHroutefromEL_10",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Section ID": "1", "Length(m)": "39", "Feed from EL": "Yes" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -0.203272590345102, 52.081692074505995 ], [ -0.202862201849073, 52.081932812840655 ] ] ] } },
{ "type": "Feature", "properties": { "Section ID": "2", "Length(m)": "21", "Feed from EL": "Yes" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -0.201603216260389, 52.08164044883334 ], [ -0.201333468851708, 52.081737214609035 ] ] ] } },
{ "type": "Feature", "properties": { "Section ID": "3", "Length(m)": "22", "Feed from EL": "Yes" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -0.201449821797515, 52.081924736099722 ], [ -0.20132844652903, 52.081741295201098 ] ] ] } },
{ "type": "Feature", "properties": { "Section ID": "4", "Length(m)": "20", "Feed from EL": "Yes" }, "geometry": { "type": "MultiLineString", "coordinates": [ [ [ -0.201320699433709, 52.081741537255184 ], [ -0.201322496251405, 52.081920714234556 ] ] ] } }
]
}
