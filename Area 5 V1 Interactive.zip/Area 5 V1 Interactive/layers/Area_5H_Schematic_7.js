var json_Area_5H_Schematic_7 = {
"type": "FeatureCollection",
"name": "Area_5H_Schematic_7",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Name": "Schematic", "Path": "Supporting_Docs\\Area 5_Schematic _Draft1.png" }, "geometry": { "type": "Point", "coordinates": [ -0.201373095558392, 52.082712362234155 ] } }
]
}
