var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'type': 'base',
            'opacity': 0.4,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var lyr_Area5full_1 = new ol.layer.Image({
                            opacity: 1,
                            title: "Ordnance Survey map",
                            
                            
                            source: new ol.source.ImageStatic({
                               url: "./layers/Area5full_1.png",
    attributions: ' ',
                                projection: 'EPSG:3857',
                                alwaysInRange: true,
                                imageExtent: [-22891.078246, 6814649.254543, -21735.899643, 6815237.266236]
                            })
                        });
var format_Area_5N_TextCover_2 = new ol.format.GeoJSON();
var features_Area_5N_TextCover_2 = format_Area_5N_TextCover_2.readFeatures(json_Area_5N_TextCover_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5N_TextCover_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5N_TextCover_2.addFeatures(features_Area_5N_TextCover_2);
var lyr_Area_5N_TextCover_2 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5N_TextCover_2,
maxResolution:0.42006699228392946,
 
                style: style_Area_5N_TextCover_2,
                interactive: false,
                title: ''
            });
var format_Area_5M_Wayleave_3 = new ol.format.GeoJSON();
var features_Area_5M_Wayleave_3 = format_Area_5M_Wayleave_3.readFeatures(json_Area_5M_Wayleave_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5M_Wayleave_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5M_Wayleave_3.addFeatures(features_Area_5M_Wayleave_3);
var lyr_Area_5M_Wayleave_3 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5M_Wayleave_3,
maxResolution:0.42006699228392946,
 
                style: style_Area_5M_Wayleave_3,
                interactive: true,
    title: '<img src="styles/legend/Area5M_Wayleave_3_0.png" /> Wayleave'
        });
var format_Area_5L_PropertyInformation_4 = new ol.format.GeoJSON();
var features_Area_5L_PropertyInformation_4 = format_Area_5L_PropertyInformation_4.readFeatures(json_Area_5L_PropertyInformation_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5L_PropertyInformation_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5L_PropertyInformation_4.addFeatures(features_Area_5L_PropertyInformation_4);cluster_Area_5L_PropertyInformation_4 = new ol.source.Cluster({
  distance: 10,
  source: jsonSource_Area_5L_PropertyInformation_4
});
var lyr_Area_5L_PropertyInformation_4 = new ol.layer.Vector({
                declutter: true,
                source:cluster_Area_5L_PropertyInformation_4,
maxResolution:0.42006699228392946,
 
                style: style_Area_5L_PropertyInformation_4,
                interactive: true,
                title: 'Property Information'
            });
var format_Area_5J_Blockage_5 = new ol.format.GeoJSON();
var features_Area_5J_Blockage_5 = format_Area_5J_Blockage_5.readFeatures(json_Area_5J_Blockage_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5J_Blockage_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5J_Blockage_5.addFeatures(features_Area_5J_Blockage_5);
var lyr_Area_5J_Blockage_5 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5J_Blockage_5,
maxResolution:0.42006699228392946,
 
                style: style_Area_5J_Blockage_5,
                interactive: true,
                title: '<img src="styles/legend/Area_5J_Blockage_5.png" /> Blockage'
            });
var format_Area_5I_AreaBreakdown_6 = new ol.format.GeoJSON();
var features_Area_5I_AreaBreakdown_6 = format_Area_5I_AreaBreakdown_6.readFeatures(json_Area_5I_AreaBreakdown_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5I_AreaBreakdown_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5I_AreaBreakdown_6.addFeatures(features_Area_5I_AreaBreakdown_6);
var lyr_Area_5I_AreaBreakdown_6 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5I_AreaBreakdown_6,
maxResolution:0.72006699228392946,
 
                style: style_Area_5I_AreaBreakdown_6,
                interactive: false,
                title: '<img src="styles/legend/Area_5I_AreaBreakdown_6.png" /> Area Breakdown'
            });
var format_Area_5H_Schematic_7 = new ol.format.GeoJSON();
var features_Area_5H_Schematic_7 = format_Area_5H_Schematic_7.readFeatures(json_Area_5H_Schematic_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5H_Schematic_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5H_Schematic_7.addFeatures(features_Area_5H_Schematic_7);
var lyr_Area_5H_Schematic_7 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5H_Schematic_7, 
                style: style_Area_5H_Schematic_7,
                interactive: true,
                title: 'Schematic'
            });
var format_Area_5G_OHroutealongOR_8 = new ol.format.GeoJSON();
var features_Area_5G_OHroutealongOR_8 = format_Area_5G_OHroutealongOR_8.readFeatures(json_Area_5G_OHroutealongOR_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5G_OHroutealongOR_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5G_OHroutealongOR_8.addFeatures(features_Area_5G_OHroutealongOR_8);
var lyr_Area_5G_OHroutealongOR_8 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5G_OHroutealongOR_8,
maxResolution:0.42006699228392946,
 minResolution:0.00028004466152261963,

                style: style_Area_5G_OHroutealongOR_8,
                interactive: true,
    title: '<img src="styles/legend/Area_5G_OHroutealongOR_8_0.png" /> O/H route along OR<br />'
        });
var format_Area_5F_UGRoute_9 = new ol.format.GeoJSON();
var features_Area_5F_UGRoute_9 = format_Area_5F_UGRoute_9.readFeatures(json_Area_5F_UGRoute_9, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5F_UGRoute_9 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5F_UGRoute_9.addFeatures(features_Area_5F_UGRoute_9);
var lyr_Area_5F_UGRoute_9 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5F_UGRoute_9,
maxResolution:0.42006699228392946,
 minResolution:0.00028004466152261963,

                style: style_Area_5F_UGRoute_9,
                interactive: true,
    title: '<img src="styles/legend/Area_5F_UGRoute_9_0.png" /> U/G Route<br />'
        });
var format_Area_5E_NewOHroutefromEL_10 = new ol.format.GeoJSON();
var features_Area_5E_NewOHroutefromEL_10 = format_Area_5E_NewOHroutefromEL_10.readFeatures(json_Area_5E_NewOHroutefromEL_10, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5E_NewOHroutefromEL_10 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5E_NewOHroutefromEL_10.addFeatures(features_Area_5E_NewOHroutefromEL_10);
var lyr_Area_5E_NewOHroutefromEL_10 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5E_NewOHroutefromEL_10,
maxResolution:0.42006699228392946,
 
                style: style_Area_5E_NewOHroutefromEL_10,
                interactive: true,
                title: '<img src="styles/legend/Area_5E_NewOHroutefromEL_10.png" /> New O/H route from EL'
            });
var format_Area_5D_NewOHroutefromNP_11 = new ol.format.GeoJSON();
var features_Area_5D_NewOHroutefromNP_11 = format_Area_5D_NewOHroutefromNP_11.readFeatures(json_Area_5D_NewOHroutefromNP_11, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5D_NewOHroutefromNP_11 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5D_NewOHroutefromNP_11.addFeatures(features_Area_5D_NewOHroutefromNP_11);
var lyr_Area_5D_NewOHroutefromNP_11 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5D_NewOHroutefromNP_11,
maxResolution:0.42006699228392946,
 
                style: style_Area_5D_NewOHroutefromNP_11,
                interactive: true,
                title: '<img src="styles/legend/Area_5D_NewOHroutefromNP_11.png" /> New O/H route from NP'
            });
var format_Area_5C_NewPole_12 = new ol.format.GeoJSON();
var features_Area_5C_NewPole_12 = format_Area_5C_NewPole_12.readFeatures(json_Area_5C_NewPole_12, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5C_NewPole_12 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5C_NewPole_12.addFeatures(features_Area_5C_NewPole_12);
var lyr_Area_5C_NewPole_12 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5C_NewPole_12,
maxResolution:0.42006699228392946,
 
                style: style_Area_5C_NewPole_12,
                interactive: true,
                title: '<img src="styles/legend/Area5C_NewPole_12.png" /> New Pole'
            });
var format_Area_5A_Pole_13 = new ol.format.GeoJSON();
var features_Area_5A_Pole_13 = format_Area_5A_Pole_13.readFeatures(json_Area_5A_Pole_13, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area_5A_Pole_13 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area_5A_Pole_13.addFeatures(features_Area_5A_Pole_13);
var lyr_Area_5A_Pole_13 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area_5A_Pole_13,
maxResolution:0.42006699228392946,
 
                style: style_Area_5A_Pole_13,
                interactive: true,
                title: '<img src="styles/legend/Pole.png" /> Pole'
            });
var format_Area5chamber_14 = new ol.format.GeoJSON();
var features_Area5chamber_14 = format_Area5chamber_14.readFeatures(json_Area5chamber_14, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area5chamber_14 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area5chamber_14.addFeatures(features_Area5chamber_14);
var lyr_Area5chamber_14 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area5chamber_14, 
maxResolution:0.42006699228392946,

                style: style_Area5chamber_14,
                interactive: true,
    title: ''
        });
var format_Area5chambers_15 = new ol.format.GeoJSON();
var features_Area5chambers_15 = format_Area5chambers_15.readFeatures(json_Area5chambers_15, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Area5chambers_15 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Area5chambers_15.addFeatures(features_Area5chambers_15);
var lyr_Area5chambers_15 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Area5chambers_15, 
                style: style_Area5chambers_15,
                interactive: false,
                title: ''
            });
			
var vector_draw = new ol.layer.Vector({
        source: new ol.source.Vector(),
        style: new ol.style.Style({
            fill: new ol.style.Fill({
                color: 'rgba(255, 255, 255, 0.2)'
            }),
            stroke: new ol.style.Stroke({
                color: '#ffcc33',
                width: 2
            }),
            image: new ol.style.Circle({
                radius: 7,
                fill: new ol.style.Fill({
                    color: '#ffcc33'
                })
            })
        })
    });	

lyr_OpenStreetMap_0.setVisible(true);lyr_Area5full_1.setVisible(true);lyr_Area_5N_TextCover_2.setVisible(true);lyr_Area_5M_Wayleave_3.setVisible(true);lyr_Area_5L_PropertyInformation_4.setVisible(true);lyr_Area_5J_Blockage_5.setVisible(true);lyr_Area_5I_AreaBreakdown_6.setVisible(true);lyr_Area_5H_Schematic_7.setVisible(true);lyr_Area_5G_OHroutealongOR_8.setVisible(true);lyr_Area_5F_UGRoute_9.setVisible(true);lyr_Area_5E_NewOHroutefromEL_10.setVisible(true);lyr_Area_5D_NewOHroutefromNP_11.setVisible(true);lyr_Area_5C_NewPole_12.setVisible(true);lyr_Area_5A_Pole_13.setVisible(true);lyr_Area5chamber_14.setVisible(true);lyr_Area5chambers_15.setVisible(false);
var layersList = [lyr_OpenStreetMap_0,lyr_Area5full_1,lyr_Area_5N_TextCover_2,lyr_Area_5M_Wayleave_3,lyr_Area_5L_PropertyInformation_4,lyr_Area_5J_Blockage_5,lyr_Area_5I_AreaBreakdown_6,lyr_Area_5H_Schematic_7,lyr_Area_5G_OHroutealongOR_8,lyr_Area_5F_UGRoute_9,lyr_Area_5E_NewOHroutefromEL_10,lyr_Area_5D_NewOHroutefromNP_11,lyr_Area_5C_NewPole_12,lyr_Area_5A_Pole_13,lyr_Area5chamber_14,lyr_Area5chambers_15];
lyr_Area_5N_TextCover_2.set('fieldAliases', {'fid': 'fid', 'id': 'id', });
lyr_Area_5M_Wayleave_3.set('fieldAliases', {'fid': 'fid', 'Item ID': 'Item ID', 'Item': 'Item', 'Land': 'Land', });
lyr_Area_5L_PropertyInformation_4.set('fieldAliases', {'fid': 'fid', 'S. No.': 'S. No.', 'UPRN': 'UPRN', 'X': 'X', 'Y': 'Y', 'Building_Number': 'Building_Number', 'Street/Road_Name': 'Street/Road_Name', 'Town': 'Town', 'Postcode': 'Postcode', 'Building Type': 'Building Type', 'Cabinet Name': 'Cabinet Name', 'Splitter Number': 'Splitter Number', 'DP Number': 'DP Number', 'DP Info': 'DP Info', });
lyr_Area_5J_Blockage_5.set('fieldAliases', {'fid': 'fid', 'Blockage': 'Blockage', 'Description': 'Description', 'Path': 'Path', });
lyr_Area_5I_AreaBreakdown_6.set('fieldAliases', {'fid': 'fid', 'id': 'id', });
lyr_Area_5H_Schematic_7.set('fieldAliases', {'fid': 'fid', 'id': 'id', 'Name': 'Name', 'Path': 'Path', 'auxiliary_storage_labeling_positionx': 'auxiliary_storage_labeling_positionx', 'auxiliary_storage_labeling_positiony': 'auxiliary_storage_labeling_positiony', });
lyr_Area_5G_OHroutealongOR_8.set('fieldAliases', {'fid': 'fid', 'Length(m)': 'Length(m)', 'Feed from EL': 'Feed from EL', 'Section ID': 'Section ID', });
lyr_Area_5F_UGRoute_9.set('fieldAliases', {'fid': 'fid', 'Section ID': 'Section ID', 'Length(m)': 'Length(m)', 'RR': 'RR', 'Comments': 'Comments', });
lyr_Area_5E_NewOHroutefromEL_10.set('fieldAliases', {'fid': 'fid', 'Section ID': 'Section ID', 'Length(m)': 'Length(m)', 'Feed from EL': 'Feed from EL', });
lyr_Area_5D_NewOHroutefromNP_11.set('fieldAliases', {'fid': 'fid', 'Section ID': 'Section ID', 'Length(m)': 'Length(m)', });
lyr_Area_5C_NewPole_12.set('fieldAliases', {'fid': 'fid', 'Pole No.': 'Pole No.', 'Wayleave': 'Wayleave', 'X': 'X', 'Y': 'Y', });
lyr_Area_5A_Pole_13.set('fieldAliases', {'fid': 'fid', 'Pole No.': 'Pole No.', 'X': 'X', 'Y': 'Y', 'Address': 'Address', 'Pole Type': 'Pole Type', 'Wayleave': 'Wayleave', 'No. of existing drop wires': 'No. of existing drop wires', 'No. of proposed drop wires': 'No. of proposed drop wires', 'Type of crown': 'Type of crown', 'Hedge Cutt': 'Hedge Cutt', 'Sufficent ': 'Sufficent ', 'Enclosure': 'Enclosure', 'Comments': 'Comments', 'Splicing Info': 'Splicing Info', 'Properties to be served from this Enclosure': 'Properties to be served from this Enclosure', });
lyr_Area5chamber_14.set('fieldAliases', {'fid': 'fid', 'Chamber No': 'Chamber No', 'X': 'X', 'Y': 'Y', 'Address': 'Address', 'Chamber Type': 'Chamber Type', 'Wayleave': 'Wayleave', 'Comments': 'Comments', 'Enclosure': 'Enclosure', 'Splicing I': 'Splicing I', 'Properties': 'Properties', 'Path': 'Path', });
lyr_Area5chambers_15.set('fieldAliases', {'WKT': 'WKT', 'fid': 'fid', 'Chamber No': 'Chamber No', 'X': 'X', 'Y': 'Y', 'Address': 'Address', 'Chamber Ty': 'Chamber Ty', 'Wayleave': 'Wayleave', 'Comments': 'Comments', 'Enclosure': 'Enclosure', 'Splicing Info': 'Splicing Info', 'Properties to be served from this DP': 'Properties to be served from this DP', 'Path': 'Path', 'field_14': 'field_14', 'field_15': 'field_15', 'field_16': 'field_16', 'field_17': 'field_17', });
lyr_Area_5N_TextCover_2.set('fieldImages', {'fid': 'Hidden', 'id': 'TextEdit', });
lyr_Area_5M_Wayleave_3.set('fieldImages', {'fid': 'Hidden', 'Item ID': 'TextEdit', 'Item': 'TextEdit', 'Land': 'TextEdit', });
lyr_Area_5L_PropertyInformation_4.set('fieldImages', {'fid': 'Hidden', 'S. No.': 'TextEdit', 'UPRN': 'TextEdit', 'X': 'TextEdit', 'Y': 'TextEdit', 'Building_Number': '', 'Street/Road_Name': '', 'Town': 'TextEdit', 'Postcode': 'TextEdit', 'Building Type': '', 'Cabinet Name': '', 'Splitter Number': '', 'DP Number': 'TextEdit', 'DP Info': 'TextEdit', });
lyr_Area_5J_Blockage_5.set('fieldImages', {'fid': 'Hidden', 'Blockage': 'TextEdit', 'Description': 'TextEdit', 'Path': 'ExternalResource', });
lyr_Area_5I_AreaBreakdown_6.set('fieldImages', {'fid': 'Hidden', 'id': 'TextEdit', });
lyr_Area_5H_Schematic_7.set('fieldImages', {'fid': 'Hidden', 'id': 'Hidden', 'Name': 'TextEdit', 'Path': 'ExternalResource', 'auxiliary_storage_labeling_positionx': 'Hidden', 'auxiliary_storage_labeling_positiony': 'Hidden', });
lyr_Area_5G_OHroutealongOR_8.set('fieldImages', {'fid': 'Hidden', 'Length(m)': 'TextEdit', 'Feed from EL': 'TextEdit', 'Section ID': 'Range', });
lyr_Area_5F_UGRoute_9.set('fieldImages', {'fid': 'Hidden', 'Section ID': 'TextEdit', 'Length(m)': 'TextEdit', 'RR': 'TextEdit', 'Comments': 'TextEdit', });
lyr_Area_5E_NewOHroutefromEL_10.set('fieldImages', {'fid': 'Hidden', 'Section ID': 'TextEdit', 'Length(m)': 'TextEdit', 'Feed from EL': 'TextEdit', });
lyr_Area_5D_NewOHroutefromNP_11.set('fieldImages', {'fid': 'Hidden', 'Section ID': 'TextEdit', 'Length(m)': 'TextEdit', });
lyr_Area_5C_NewPole_12.set('fieldImages', {'fid': 'Hidden', 'Pole No.': 'TextEdit', 'Wayleave': 'TextEdit', 'X': 'Hidden', 'Y': 'Hidden', });
lyr_Area_5A_Pole_13.set('fieldImages', {'fid': 'Hidden', 'Pole No.': 'TextEdit', 'X': 'TextEdit', 'Y': 'TextEdit', 'Address': 'TextEdit', 'Pole Type': 'TextEdit', 'Wayleave': 'TextEdit', 'No. of existing drop wires': '', 'No. of proposed drop wires': '', 'Type of crown': '', 'Hedge Cutt': 'TextEdit', 'Sufficent ': 'TextEdit', 'Enclosure': 'TextEdit', 'Comments': 'TextEdit', 'Splicing Info': 'TextEdit', 'Properties to be served from this Enclosure': 'TextEdit', });
lyr_Area5chamber_14.set('fieldImages', {'fid': 'Hidden', 'Chamber No': 'TextEdit', 'X': 'TextEdit', 'Y': 'TextEdit', 'Address': 'TextEdit', 'Chamber Type': 'TextEdit', 'Wayleave': 'TextEdit', 'Comments': 'TextEdit', 'Enclosure': 'TextEdit', 'Splicing I': 'TextEdit', 'Properties': 'TextEdit', 'Path': 'ExternalResource', });
lyr_Area5chambers_15.set('fieldImages', {'WKT': 'Hidden', 'fid': 'Hidden', 'Chamber No': 'TextEdit', 'X': 'TextEdit', 'Y': 'TextEdit', 'Address': 'TextEdit', 'Chamber Ty': 'TextEdit', 'Wayleave': 'TextEdit', 'Comments': 'TextEdit', 'Enclosure': 'TextEdit', 'Splicing Info': 'TextEdit', 'Properties to be served from this DP': 'TextEdit', 'Path': 'TextEdit', 'field_14': 'Hidden', 'field_15': 'Hidden', 'field_16': 'Hidden', 'field_17': 'Hidden', });
lyr_Area_5N_TextCover_2.set('fieldLabels', {'id': 'no label', });
lyr_Area_5M_Wayleave_3.set('fieldLabels', {'Item ID': 'header label', 'Item': 'inline label', 'Land': 'inline label', });
lyr_Area_5L_PropertyInformation_4.set('fieldLabels', {'S. No.': 'header label', 'UPRN': 'inline label', 'X': 'inline label', 'Y': 'inline label', 'Building_Number': 'inline label', 'Street/Road_Name': 'inline label', 'Town': 'inline label', 'Postcode': 'inline label', 'Building Type': 'inline label', 'Cabinet Name': 'inline label', 'Splitter Number': 'inline label', 'DP Number': 'inline label', 'DP Info': 'inline label', });
lyr_Area_5J_Blockage_5.set('fieldLabels', {'Blockage': 'header label', 'Description': 'inline label', 'Path': 'no label', });
lyr_Area_5I_AreaBreakdown_6.set('fieldLabels', {'id': 'no label', });
lyr_Area_5H_Schematic_7.set('fieldLabels', {'Name': 'header label', 'Path': 'no label', });
lyr_Area_5G_OHroutealongOR_8.set('fieldLabels', {'Length(m)': 'header label', 'Feed from EL': 'inline label', 'Section ID': 'inline label', });
lyr_Area_5F_UGRoute_9.set('fieldLabels', {'Section ID': 'header label', 'Length(m)': 'inline label', 'RR': 'inline label', 'Comments': 'inline label', });
lyr_Area_5E_NewOHroutefromEL_10.set('fieldLabels', {'Section ID': 'header label', 'Length(m)': 'inline label', 'Feed from EL': 'inline label', });
lyr_Area_5D_NewOHroutefromNP_11.set('fieldLabels', {'Section ID': 'header label', 'Length(m)': 'inline label', });
lyr_Area_5C_NewPole_12.set('fieldLabels', {'Pole No.': 'header label', 'Wayleave': 'red label', });
lyr_Area_5A_Pole_13.set('fieldLabels', {'Pole No.': 'header label', 'X': 'inline label', 'Y': 'inline label', 'Address': 'inline label', 'Pole Type': 'inline label', 'Wayleave': 'red label', 'No. of existing drop wires': 'inline label', 'No. of proposed drop wires': 'inline label', 'Type of crown': 'inline label', 'Hedge Cutt': 'inline label', 'Sufficent ': 'inline label', 'Enclosure': 'inline label', 'Comments': 'inline label', 'Splicing Info': 'inline label', 'Properties to be served from this Enclosure': 'inline label', });
lyr_Area5chamber_14.set('fieldLabels', {'Chamber No': 'header label', 'X': 'inline label', 'Y': 'inline label', 'Address': 'inline label', 'Chamber Type': 'inline label', 'Wayleave': 'red label', 'Comments': 'inline label', 'Enclosure': 'inline label', 'Splicing I': 'inline label', 'Properties': 'inline label', 'Path': 'no label', });
lyr_Area5chambers_15.set('fieldLabels', {'Chamber No': 'no label', 'X': 'no label', 'Y': 'no label', 'Address': 'no label', 'Chamber Ty': 'no label', 'Wayleave': 'no label', 'Comments': 'no label', 'Enclosure': 'no label', 'Splicing Info': 'no label', 'Properties to be served from this DP': 'no label', 'Path': 'no label', });
lyr_Area5chambers_15.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});